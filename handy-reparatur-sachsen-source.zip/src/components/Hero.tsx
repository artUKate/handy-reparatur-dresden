import { Phone, ArrowRight, ShieldCheck, Clock, CheckCircle2, MessageCircle, Sparkles } from 'lucide-react';
import { COMPANY_INFO } from '../data';
import HeroMapCard from './HeroMapCard';

interface HeroProps {
  onScrollToPricing: () => void;
  onOpenPriceCalculator: () => void;
}

export default function Hero({ onScrollToPricing, onOpenPriceCalculator }: HeroProps) {
  return (
    <section
      id="hero-section"
      className="relative pt-32 pb-16 md:pt-40 md:pb-24 overflow-hidden"
    >
      {/* Background ambient lighting effects */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] sm:w-[900px] h-[400px] bg-blue-600/10 blur-[140px] rounded-full -z-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          {/* Left Column: Clean Typography & Direct Action */}
          <div className="lg:col-span-7 text-center lg:text-left">
            {/* Dresden Location & Trust Tag */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-xl text-xs font-medium text-white/70 mb-6 shadow-sm">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="text-white font-medium">Dresden · Weißeritzstraße 40</span>
              <span className="text-white/20">|</span>
              <span className="text-white/60">Ohne Termin · Sofort vor Ort</span>
            </div>

            {/* Main Headline */}
            <h1
              id="hero-title"
              className="text-5xl sm:text-7xl xl:text-8xl font-bold tracking-tight mb-6 text-white leading-[0.95]"
            >
              Dein Gerät.<br />
              <span className="text-white/40">Wieder wie neu.</span>
            </h1>

            {/* Subline */}
            <p
              id="hero-subline"
              className="text-lg sm:text-xl text-white/60 max-w-2xl mx-auto lg:mx-0 font-light leading-relaxed mb-8"
            >
              Professionelle Sofort-Reparatur für Smartphone, Tablet &amp; Laptop in Dresden.
              Ohne Termin. 100% Datensicherheit ohne Werksreset. 12 Monate Garantie.
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center lg:justify-start gap-4 mb-8">
              {/* Primary CTA: Jetzt anrufen */}
              <a
                href={`tel:${COMPANY_INFO.phoneClean}`}
                id="hero-primary-call-cta"
                className="inline-flex items-center justify-center gap-3 bg-white text-black px-8 py-4 rounded-full font-semibold hover:bg-white/90 transition-all shadow-lg shadow-white/5 active:scale-98 group"
              >
                <Phone className="w-4 h-4 fill-current" />
                <span>Jetzt anrufen: {COMPANY_INFO.phone}</span>
              </a>

              {/* Secondary CTA: Zum Preisrechner */}
              <button
                type="button"
                id="hero-secondary-prices-cta"
                onClick={onOpenPriceCalculator}
                className="inline-flex items-center justify-center gap-2 bg-white/10 border border-white/10 backdrop-blur-lg px-8 py-4 rounded-full font-semibold hover:bg-white/20 transition-all text-white active:scale-98"
              >
                <span>Preis &amp; Dauer berechnen</span>
                <ArrowRight className="w-4 h-4 text-white/70" />
              </button>
            </div>

            {/* Fast WhatsApp Chat link */}
            <div className="flex items-center justify-center lg:justify-start gap-3 text-xs text-white/50 mb-8">
              <span>Schnelle Preisauskunft via Chat?</span>
              <a
                href={`https://wa.me/${COMPANY_INFO.whatsapp.replace('+', '')}?text=${encodeURIComponent(
                  COMPANY_INFO.whatsappText
                )}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 font-medium text-emerald-400 hover:text-emerald-300 transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                WhatsApp Sofort-Anfrage
              </a>
            </div>

            {/* Key Trust Points */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 border-t border-white/10 max-w-2xl mx-auto lg:mx-0">
              <div className="flex items-center gap-2 text-xs text-white/70">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Ohne Termin</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-white/70">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>100% Datensicher</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-white/70">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Diagnose ab 0€</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-white/70">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Ø 35 Min Express</span>
              </div>
            </div>
          </div>

          {/* Right Column: Stylized Interactive Dresden Radar & Map Fragment */}
          <div className="lg:col-span-5">
            <HeroMapCard />
          </div>
        </div>
      </div>
    </section>
  );
}
