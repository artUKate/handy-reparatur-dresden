import { ShieldCheck, Cpu, Microscope, Sparkles, Award, CheckCircle, Users } from 'lucide-react';
import { WORKSHOP_STATS, COMPANY_INFO } from '../data';

export default function WorkshopAbout() {
  const labFeatures = [
    {
      title: 'ESD-Schutzarbeitsplatz',
      desc: 'Elektrostatisch entladene Präzisionsplätze verhindern unsichtbare Spannungsüberschläge auf empfindliche Logikplatinen.',
      icon: '⚡',
    },
    {
      title: 'Stereo-Mikroskopie & Mikrolöten',
      desc: 'Feinste Bauteile (BGA-Chips, Ladecontroller, SMD-Kondensatoren) werden unter hochauflösenden Mikroskopen instand gesetzt.',
      icon: '🔬',
    },
    {
      title: 'Chemisches Ultraschallbad',
      desc: 'Bei Wasserschäden lösen wir aggressive Oxidationsrückstände und Salze mikrofein von den Leiterbahnen.',
      icon: '💧',
    },
    {
      title: 'OEM- & Original-Ersatzteile',
      desc: 'Strenge Qualitätskontrolle jedes einzelnen Displays auf Farbtreue, Helligkeit, Touch-Reaktionszeit und True Tone.',
      icon: '🛡️',
    },
  ];

  return (
    <section id="werkstatt" className="py-20 md:py-28 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-md text-white/70 text-xs font-semibold uppercase tracking-wider mb-4">
            <span>Präzision &amp; Meisterhandwerk</span>
          </div>

          <h2
            id="about-heading"
            className="text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight"
          >
            Hightech-Werkstatt statt Reparatur-Bude
          </h2>

          <p className="mt-4 text-base sm:text-lg text-white/60 font-light leading-relaxed">
            Wir haben das Reparatur-Erlebnis neu gedacht: Transparente Labor-Arbeit, modernstes Diagnose-Equipment und ehrliche Handwerkskunst direkt in Dresden.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mb-16">
          {WORKSHOP_STATS.map((stat) => (
            <div
              key={stat.label}
              className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 text-center shadow-lg"
            >
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-white tracking-tight mb-2">
                {stat.value}
              </div>
              <div className="text-xs sm:text-sm text-white/50 font-light">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Laboratory & Workshop Visual Features */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-16">
          {/* Left Text & Lab Highlights */}
          <div className="lg:col-span-7 space-y-6">
            <h3 className="text-2xl sm:text-3xl font-bold text-white">
              Warum echte Erfahrung den Unterschied macht
            </h3>
            <p className="text-sm sm:text-base text-white/70 leading-relaxed font-light">
              Moderne Smartphones und MacBooks sind hochkompakt verklebt. Schon kleine Fehler bei unqualifizierten Eigenversuchen können das Mainboard dauerhaft zerstören oder Face ID / Touch ID deaktivieren.
            </p>
            <p className="text-sm sm:text-base text-white/70 leading-relaxed font-light">
              In unserer Dresdner Werkstatt an der Weißeritzstraße 40 arbeiten erfahrene Elektroniker mit Spezialwerkzeugen für schonende Öffnung, präzise Verklebung und saubere Datenrettung.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              {labFeatures.map((feat) => (
                <div
                  key={feat.title}
                  className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xl"
                >
                  <div className="text-xl mb-2">{feat.icon}</div>
                  <h4 className="text-sm font-semibold text-white mb-1">{feat.title}</h4>
                  <p className="text-xs text-white/50 leading-snug font-light">{feat.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right Visual Card with Real Workshop Photography */}
          <div className="lg:col-span-5 space-y-4">
            <div className="rounded-3xl overflow-hidden border border-white/15 bg-white/5 backdrop-blur-xl shadow-2xl relative group">
              <div className="aspect-[4/3] relative overflow-hidden bg-neutral-900">
                <img
                  src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1000&q=80"
                  alt="Hightech Elektronik-Labor und Mikrolöt-Arbeitsplatz in Dresden"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 opacity-85 group-hover:opacity-95"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
              </div>

              {/* Floating Guarantee Overlay */}
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-2xl bg-black/70 backdrop-blur-xl border border-white/15 text-left">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-white/10 text-xs">
                  <span className="text-blue-400 font-semibold tracking-wide">
                    Labor Dresden-Mitte
                  </span>
                  <span className="text-emerald-400 font-medium text-[11px]">
                    100% Datensicherheit
                  </span>
                </div>

                <p className="text-xs text-white/80 leading-relaxed font-light mb-2">
                  Deine privaten Fotos, WhatsApp-Chats und Passwörter bleiben garantiert unangetastet. Kein Werksreset nötig.
                </p>

                <div className="flex items-center justify-between text-[11px] text-white/50 pt-1 border-t border-white/10">
                  <span>📍 {COMPANY_INFO.fullAddress}</span>
                  <span className="text-white/70">Ohne Termin</span>
                </div>
              </div>
            </div>

            {/* Quick Trust Checklist */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xl grid grid-cols-2 gap-3 text-xs text-white/80">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Original- &amp; OEM-Teile</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>12 Monate Garantie</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>ESD-geschützt</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Vorab-Prüfung 0€</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
