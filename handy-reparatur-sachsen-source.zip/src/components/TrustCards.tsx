import { Zap, ShieldCheck, BadgeDollarSign, Clock, ArrowRight } from 'lucide-react';
import { TRUST_POINTS } from '../data';

interface TrustCardsProps {
  onOpenPriceCalculator: () => void;
}

export default function TrustCards({ onOpenPriceCalculator }: TrustCardsProps) {
  const icons = [
    <Zap key="1" className="w-6 h-6 text-cyan-400" />,
    <ShieldCheck key="2" className="w-6 h-6 text-emerald-400" />,
    <BadgeDollarSign key="3" className="w-6 h-6 text-sky-400" />,
  ];

  return (
    <section id="trust-section" className="py-16 md:py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-semibold uppercase tracking-wider text-white/70 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-md mb-4 inline-block">
            Sachsen-Reparatur Direkt Vor Ort
          </span>
          <h2
            id="trust-heading"
            className="text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight"
          >
            Premium-Service direkt vor Ort.
          </h2>
          <p className="mt-4 text-base sm:text-lg text-white/60 leading-relaxed font-light">
            Statt tagelangem Warten beim Hersteller oder teurem Neukauf: Unsere qualifizierten Techniker in Dresden reparieren dein Gerät transparent und sicher.
          </p>
        </div>

        {/* 3 Glassmorphism Cards matching Design HTML */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {TRUST_POINTS.map((point, index) => (
            <div
              key={point.title}
              className="group rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl p-8 hover:border-white/20 transition-all duration-300 flex flex-col justify-between shadow-xl"
            >
              <div>
                {/* Icon & Tag */}
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/10 flex items-center justify-center group-hover:scale-105 transition-transform">
                    {icons[index]}
                  </div>
                  <span className="text-xs font-medium text-white/60 px-3 py-1 rounded-full bg-white/5 border border-white/10">
                    {point.short}
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-xl font-semibold text-white mb-2 group-hover:text-blue-300 transition-colors">
                  {point.title}
                </h3>

                {/* Text */}
                <p className="text-sm text-white/50 leading-relaxed">
                  {point.text}
                </p>
              </div>

              {/* Bottom Reassurance Feature */}
              <div className="mt-8 pt-5 border-t border-white/10 flex items-center justify-between text-xs text-white/60">
                <span className="font-medium text-white/70">
                  {index === 0 && '⚡ Ø Reparaturzeit: 30–60 Min'}
                  {index === 1 && '🔒 Kein Zurücksetzen nötig'}
                  {index === 2 && '🏷️ Vorab-Diagnose ab 0€'}
                </span>
                <span className="text-blue-400 font-medium group-hover:translate-x-1 transition-transform">
                  Details →
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
